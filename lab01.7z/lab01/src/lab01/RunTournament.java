/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01;

/**
 *
 * @author 21912055
 */
public class RunTournament {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Team fcb, tfc, fcs;
        fcb= new Team ("FC Beijing", "CN", 0);
        tfc = new Team ("Toulouse FC", "FR", 0);
        fcs = new Team ("FC Seville", "SP", 0);
        // TODO code application logic here
        // System.out.println("Citizenship of Sevilla : "+ fcs.getTeamCitizenship() );
        // Match match = new Match()
           
    Tournament t2is;
    t2is = new Tournament("2is world tournament");
    t2is.invite(fcb); 
    t2is.invite(tfc); 
    t2is.invite(fcs);
    
    Match match = new Match();
    match.playMatch(fcb, tfc, 1, 4);
    match.playMatch(tfc, fcs, 2, 3);
    match.playMatch(fcs, fcb, 4, 0);
      
    //match = new Match(tfc, fcs, 2, 3);
    //match = new Match(fcs, fcb, 0, 5);
    
    match.winner(fcb.points, tfc.points, fcs.points);
    
    //System.out.println("invited teams : "+ invited);
                
    }
    
}
