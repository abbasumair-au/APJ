/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01;

/**
 *
 * @author 21912055
 */
public class Team {
    
    private String teamName;

    private String teamCitizenship;
    public int points;

    /**
     * Get the value of teamCitizenship
     *
     * @return the value of teamCitizenship
     */
    public Team(String teamName, String teamCitizenship, int points) {
        this.teamName = teamName;
        this.teamCitizenship = teamCitizenship;
        this.points = points;
    }

    
   //Team team = new Team();
    
    public String getTeamCitizenship() {
        return teamCitizenship;
    }

   
   
    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getName() {
        return teamName;
    }
    
  
    
   

}
