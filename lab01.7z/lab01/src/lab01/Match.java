/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01;

/**
 *
 * @author 21912055
 */
public class Match {
    private  int scoreA, scoreB, pointsfcb, pointstfc, pointsfcs;
    private Team teamA, teamB;

    public Match(){
    }
    public Match( Team teamA, Team teamB, int scoreA, int scoreB) {
        this.scoreA = scoreA;
        this.scoreB = scoreB;
        this.teamA = teamA;
        this.teamA = teamB;
    }
    
    public int getScoreA() {
        return scoreA;
    }

    public int getScoreB() { 
        return scoreB;
    }
    
    public void winner(int fcb, int tfc, int fcs) {
        System.out.println("points of fcb " + fcb ); 
          System.out.println("points of tfc " + tfc ); 
            System.out.println("points of fcs " + fcs); 
            if(fcb>tfc)
                if(fcb>fcs)
                    System.out.println("Winner is fcb with points" + fcb);
            
            if(tfc>fcb)
                if(tfc>fcs)
                    System.out.println("Winner is tfc with points " + tfc);
            
            if(fcs>tfc)
                if(fcs>fcb)
                    System.out.println("Winner is fcs with points: " + fcs);
            
            
           
//        if (scoreA > scoreB)
//          return  teamA;
//        if (scoreB > scoreA)
//            return teamB;
//        else;
//        return null;
    }

//    public int points(Team t) {
//           if (this.winner()==null)
//                   return 1;
//           if (t==winner())
//                   return 3;
//           else
//               return 0;
//    }
    
    public void playMatch(Team t1, Team t2, int score1, int score2){
     if(score1<score2){
         t2.points= t2.points + 3;
          System.out.println( t2.getName()+ " won the match");
          }
     else if(score1>score2){
          System.out.println( t1.getName()+ " won the match");
             t1.points= t1.points + 3;
             }
     else {
          System.out.println("Its a draw"); 
           t2.points= t2.points + 1;
           t1.points= t1.points + 1;
     }
    }
}
