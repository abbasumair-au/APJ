/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab01;

import java.util.ArrayList;

/**
 *
 * @author 21912055
 */
public class Tournament {
    String name;
    static ArrayList<Team> invitedTeams = new ArrayList();
    Match match = new Match();

    public Tournament(String name) {
        this.name = name;
    }
    
    public void invite(Team t){
        invitedTeams.add(t);
        System.out.println( t.getName()+ " has been invited to 2is tournament");
    }
    
    
//    public Team inviteTeam (){
//        
//    }
    
   
    
}
